<nav>
    <a href="create_task.php">Create Task</a> |
    <a href="view_tasks.php">View Tasks</a> |
    <a href="settings.html">Settings</a> |
    <a href="logout.php">Logout</a>
</nav>
<hr>
